Link do Vídeo explicando o código e mostrando resultados:

T1 - Simulação e Métodos Analíticos

Grupo: Igor Cardona Alves, João Vitor Pioner, Henrique Andreata, Nathan Schostack

Para compilar o programa: javac *.java

Para rodar o programa: java Main

Todos os parâmetros do algoritmo estão presentes na função main da classe Main.java.
Para alterar os parâmetros, basta alterá-los na main, salvar e recompilar o programa.

O resultado final aparece no terminal e em um arquivo CSV que é gerado automaticamente,
contendo todos os instantes de tempo da execução.

Junto ao código, estamos enviando o resultado das simulações propostas no enunciado:
- "Simulacao Media das Filas.xlsx"